# Mirage: автоматические правки AyuGramDesktop во время сборки.
# Запускается из папки tdesktop. Ничего руками делать не нужно.
import re, sys, pathlib

root = pathlib.Path(".")
mir = root / "Telegram/SourceFiles/mirage"
assert mir.exists(), "нет папки Telegram/SourceFiles/mirage"

# 1. Все внутренние include делаем вида "mirage/..."
pref = ("Core", "Storage", "Profile", "Fragment", "Gifts", "Clone", "UI")
pat = re.compile(r'#include "((?:%s)/[^"]+)"' % "|".join(pref))
for f in mir.rglob("*"):
    if f.suffix in (".h", ".cpp"):
        t = f.read_text(encoding="utf-8")
        n = pat.sub(r'#include "mirage/\1"', t)
        if n != t:
            f.write_text(n, encoding="utf-8")
print("[ok] includes исправлены")

# 2. CMake
cm = root / "Telegram/CMakeLists.txt"
t = cm.read_text(encoding="utf-8")
if "MIRAGE_SOURCES" not in t:
    t += """

# --- Mirage (auto) ---
file(GLOB_RECURSE MIRAGE_SOURCES CONFIGURE_DEPENDS
    RELATIVE ${CMAKE_CURRENT_SOURCE_DIR}/SourceFiles
    ${CMAKE_CURRENT_SOURCE_DIR}/SourceFiles/mirage/*.cpp)
nice_target_sources(Telegram SourceFiles PRIVATE ${MIRAGE_SOURCES})
"""
    cm.write_text(t, encoding="utf-8")
print("[ok] CMake")

# 3. Пункт меню «Повторить профиль»
cmf = root / "Telegram/SourceFiles/ayu/ui/context_menu/context_menu.cpp"
if not cmf.exists():
    print("[warn] нет context_menu.cpp — меню не добавлено, сборка продолжится")
    sys.exit(0)
src = cmf.read_text(encoding="utf-8")
if "Mirage::CloneProfile" in src:
    print("[ok] меню уже пропатчено"); sys.exit(0)

m = re.search(r'\bAddAyuGramActions\s*\(', src)
# ищем определение (после скобок идёт «{»)
defn = None
for m in re.finditer(r'\bAddAyuGramActions\s*\(', src):
    i = m.end(); depth = 1
    while depth and i < len(src):
        depth += {'(': 1, ')': -1}.get(src[i], 0); i += 1
    rest = src[i:i+40].lstrip()
    if rest.startswith("{"):
        defn = (m.end(), i - 1, src.index("{", i)); break
if not defn:
    print("[warn] не нашёл определение AddAyuGramActions — меню не добавлено"); sys.exit(0)

params_txt = src[defn[0]:defn[1]]
params, depth, cur = [], 0, ""
for ch in params_txt:
    if ch in "<([": depth += 1
    if ch in ">)]": depth -= 1
    if ch == "," and depth == 0:
        params.append(cur); cur = ""
    else: cur += ch
params.append(cur)
print("[info] параметры:", [p.strip() for p in params])

def name_of(p):
    p = re.sub(r'=.*$', '', p.strip(), flags=re.S)
    mm = re.search(r'([A-Za-z_]\w*)\s*$', p)
    return mm.group(1) if mm else None

peer = cb = None
for p in params:
    if "PeerData" in p and not peer: peer = name_of(p)
    if ("MenuCallback" in p or "addCallback" in p) and not cb: cb = name_of(p)
if not peer or not cb:
    print("[warn] не определил peer/callback — меню не добавлено"); sys.exit(0)

body_pos = defn[2] + 1
code = f"""
\t// --- Mirage ---
\t{{
\t\tPeerData *miragePeer = {peer};
\t\tif (miragePeer && !miragePeer->isSelf()) {{
\t\t\t{cb}({{
\t\t\t\t.text = Mirage::CloneMenuText(),
\t\t\t\t.handler = [=] {{
\t\t\t\t\tconst auto u = miragePeer->asUser();
\t\t\t\t\tMirage::CloneProfile(
\t\t\t\t\t\t(long long)miragePeer->id.value,
\t\t\t\t\t\tmiragePeer->name(),
\t\t\t\t\t\tu ? u->username() : QString(),
\t\t\t\t\t\tu ? u->isPremium() : false);
\t\t\t\t}},
\t\t\t}});
\t\t}}
\t}}
"""
src = src[:body_pos] + code + src[body_pos:]

# include'ы после последнего #include
incs = list(re.finditer(r'^#include .*$', src, flags=re.M))
last = incs[-1].end()
src = src[:last] + '\n#include "mirage/mirage_hooks.h"\n#include "data/data_peer.h"\n#include "data/data_user.h"' + src[last:]
cmf.write_text(src, encoding="utf-8")
print(f"[ok] меню добавлено (peer={peer}, callback={cb})")
