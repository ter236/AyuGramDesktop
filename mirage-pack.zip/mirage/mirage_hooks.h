// Mirage — local visual layer for AyuGram / Telegram Desktop
#pragma once

#include <QtCore/QString>

namespace Mirage {

// Safe to call many times; initializes the local store once.
void EnsureInit();

// Text of the menu item and what it does (no tdesktop types here).
QString CloneMenuText();
void CloneProfile(
	long long peerId,
	const QString &displayName,
	const QString &username,
	bool hasPremium);

} // namespace Mirage
