#pragma once

#include "Core/Types.h"
#include <QPainter>
#include <QRectF>
#include <QColor>

namespace Mirage {

// Draws avatar frame over an already-painted userpic.
// Call after painting the circular/rounded avatar image.

class FramePainter {
public:
    static void paint(
        QPainter &p,
        const QRectF &avatarRect,
        const ProfileFrame &frame,
        qreal devicePixelRatio = 1.0);

    static QColor colorFromArgb(uint32_t argb);
};

} // namespace Mirage
