#include "FramePainter.h"
#include <QPainterPath>
#include <QtMath>

namespace Mirage {

QColor FramePainter::colorFromArgb(uint32_t argb) {
    return QColor(
        int((argb >> 16) & 0xFF),
        int((argb >> 8) & 0xFF),
        int(argb & 0xFF),
        int((argb >> 24) & 0xFF));
}

void FramePainter::paint(
    QPainter &p,
    const QRectF &avatarRect,
    const ProfileFrame &frame,
    qreal /*dpr*/) {

    if (frame.style == FrameStyle::None) {
        return;
    }

    p.save();
    p.setRenderHint(QPainter::Antialiasing, true);

    const qreal t = qMax<qreal>(1.0, frame.thickness);
    const QRectF ring = avatarRect.adjusted(-t, -t, t, t);
    const QColor primary = colorFromArgb(frame.primaryColor);
    const QColor secondary = colorFromArgb(frame.secondaryColor);

    switch (frame.style) {
    case FrameStyle::Simple: {
        QPen pen(primary, t);
        pen.setJoinStyle(Qt::RoundJoin);
        p.setPen(pen);
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(ring);
        break;
    }
    case FrameStyle::Gradient: {
        QLinearGradient grad(ring.topLeft(), ring.bottomRight());
        grad.setColorAt(0.0, primary);
        grad.setColorAt(1.0, secondary);
        QPen pen(QBrush(grad), t);
        pen.setJoinStyle(Qt::RoundJoin);
        p.setPen(pen);
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(ring);
        break;
    }
    case FrameStyle::Neon: {
        // Outer glow
        for (int i = 4; i >= 1; --i) {
            QColor glow = primary;
            glow.setAlpha(30 * i);
            QPen pen(glow, t + i * 2.5);
            p.setPen(pen);
            p.setBrush(Qt::NoBrush);
            p.drawEllipse(ring);
        }
        QPen core(primary, t);
        p.setPen(core);
        p.drawEllipse(ring);
        break;
    }
    case FrameStyle::Glass: {
        QColor glass = primary;
        glass.setAlpha(140);
        QPen pen(glass, t);
        p.setPen(pen);
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(ring);
        // highlight arc
        QPen hi(QColor(255, 255, 255, 90), t * 0.5);
        p.setPen(hi);
        p.drawArc(ring, 40 * 16, 100 * 16);
        break;
    }
    case FrameStyle::AnimatedPulse:
    case FrameStyle::AnimatedRotate: {
        // Static fallback for first version; animation wired later via timer
        QPen pen(primary, t);
        p.setPen(pen);
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(ring);
        QColor soft = primary;
        soft.setAlpha(80);
        p.setPen(QPen(soft, t * 2.0));
        p.drawEllipse(ring.adjusted(-2, -2, 2, 2));
        break;
    }
    case FrameStyle::CustomImage: {
        // Path is relative; actual image load is done by caller / cache
        QPen pen(primary, t);
        p.setPen(pen);
        p.setBrush(Qt::NoBrush);
        p.drawEllipse(ring);
        break;
    }
    default:
        break;
    }

    p.restore();
}

} // namespace Mirage
