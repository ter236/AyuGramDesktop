#include "PanelModels.h"
#include "Storage/LocalStore.h"
#include "Profile/ProfileService.h"
#include "Fragment/FragmentService.h"
#include <sstream>
#include <iomanip>

namespace Mirage {
namespace {

std::string formatStars(int64_t v) {
    std::ostringstream o;
    o.imbue(std::locale(""));
    // simple space thousands
    std::string s = std::to_string(v);
    std::string out;
    int cnt = 0;
    for (int i = int(s.size()) - 1; i >= 0; --i) {
        if (cnt && cnt % 3 == 0) out.insert(out.begin(), ' ');
        out.insert(out.begin(), s[i]);
        ++cnt;
    }
    return out;
}

std::string moneyText(Money m) {
    switch (m.currency) {
    case Currency::Stars: return formatStars(m.amount) + " Stars";
    case Currency::Ton:   return std::to_string(m.amount / 1000000000.0) + " TON";
    case Currency::Rub:   return formatStars(m.amount / 100) + " ₽";
    }
    return std::to_string(m.amount);
}

} // namespace

// ---- SettingsPanelModel ----

std::vector<BalanceRow> SettingsPanelModel::balances() const {
    auto s = LocalStore::instance().settings();
    return {
        { "Stars", formatStars(s.fakeStarsBalance), Currency::Stars },
        { "TON", std::to_string(s.fakeTonNanos / 1e9), Currency::Ton },
        { "Рубли", formatStars(s.fakeRubKopecks / 100) + " ₽", Currency::Rub },
    };
}

std::vector<MenuRow> SettingsPanelModel::sections() const {
    return {
        { "profile",  "Кастомизация профиля", "Юзернейм, номер, рамка, premium", "person" },
        { "fragment", "Fragment",             "Коллекционные юзернеймы и номера", "shop" },
        { "gifts",    "Подарки",              "Локальные подарки и коллекция", "gift" },
        { "clone",    "История клонов",       "Скопированные профили", "copy" },
        { "ledger",   "История операций",    "Покупки и начисления", "list" },
        { "about",    "О моде",               "Mirage · только локально", "info" },
    };
}

void SettingsPanelModel::refresh() {
    LocalStore::instance().load();
}

void SettingsPanelModel::addStars(int64_t amount) {
    LocalStore::instance().credit(Currency::Stars, amount, "Пополнение", "Ручное");
    LocalStore::instance().save();
}

void SettingsPanelModel::addRub(int64_t kopecks) {
    LocalStore::instance().credit(Currency::Rub, kopecks, "Пополнение", "Ручное");
    LocalStore::instance().save();
}

void SettingsPanelModel::resetBalancesToDefault() {
    LocalStore::instance().updateSettings([](Settings &s) {
        s.fakeStarsBalance = 50000;
        s.fakeTonNanos = 0;
        s.fakeRubKopecks = 1000000;
    });
    LocalStore::instance().save();
}

bool SettingsPanelModel::realisticMode() const {
    return LocalStore::instance().settings().realisticMode;
}

void SettingsPanelModel::setRealisticMode(bool on) {
    LocalStore::instance().updateSettings([on](Settings &s) { s.realisticMode = on; });
    LocalStore::instance().save();
}

bool SettingsPanelModel::phantomRibbon() const {
    return LocalStore::instance().settings().showPhantomRibbon;
}

void SettingsPanelModel::setPhantomRibbon(bool on) {
    LocalStore::instance().updateSettings([on](Settings &s) { s.showPhantomRibbon = on; });
    LocalStore::instance().save();
}

// ---- FragmentShopModel ----

void FragmentShopModel::ensureCatalog() {
    FragmentService::instance().ensureDemoCatalog();
}

std::vector<FragmentRow> FragmentShopModel::rows() const {
    std::vector<FragmentRow> out;
    for (const auto &l : FragmentService::instance().catalog()) {
        FragmentRow r;
        r.value = l.value;
        r.kind = l.kind;
        r.price = l.price;
        r.priceText = moneyText(l.price);
        r.owned = l.isOwnedByUser;
        out.push_back(r);
    }
    return out;
}

bool FragmentShopModel::buy(const FragmentRow &row) {
    _lastError.clear();
    if (row.owned) {
        _lastError = "Уже куплено";
        return false;
    }
    if (!FragmentService::instance().buy(row.value, row.kind, row.price)) {
        _lastError = "Недостаточно средств";
        return false;
    }
    return true;
}

std::string FragmentShopModel::lastError() const {
    return _lastError;
}

// ---- ProfileCustomizeModel ----

ProfileOverlay ProfileCustomizeModel::overlay() const {
    return ProfileService::instance().overlay();
}

void ProfileCustomizeModel::setUsername(const std::string &u, bool collectible) {
    ProfileService::instance().setDisplayUsername(u, collectible);
}

void ProfileCustomizeModel::clearUsername() {
    ProfileService::instance().clearUsername();
}

void ProfileCustomizeModel::setPhone(const std::string &p, bool collectible) {
    ProfileService::instance().setDisplayPhone(p, collectible);
}

void ProfileCustomizeModel::clearPhone() {
    ProfileService::instance().clearPhone();
}

void ProfileCustomizeModel::setFrameStyle(FrameStyle style) {
    auto f = ProfileService::instance().effectiveFrame();
    f.style = style;
    ProfileService::instance().setFrame(f);
}

void ProfileCustomizeModel::setFrameColor(uint32_t argb) {
    auto f = ProfileService::instance().effectiveFrame();
    f.primaryColor = argb;
    ProfileService::instance().setFrame(f);
}

void ProfileCustomizeModel::setForcePremium(bool on) {
    ProfileService::instance().setForcePremium(on);
}

void ProfileCustomizeModel::reset() {
    ProfileService::instance().resetAll();
}

std::vector<CollectibleRow> ProfileCustomizeModel::ownedCollectibles() const {
    std::vector<CollectibleRow> out;
    for (const auto &c : LocalStore::instance().ownedCollectibles()) {
        CollectibleRow r;
        r.id = c.id;
        r.value = c.value;
        r.kind = c.kind;
        r.worn = c.isWorn;
        r.priceText = moneyText(c.purchasePrice);
        out.push_back(r);
    }
    return out;
}

bool ProfileCustomizeModel::wear(CollectibleId id) {
    return ProfileService::instance().wearCollectible(id);
}

void ProfileCustomizeModel::unwear(CollectibleKind kind) {
    ProfileService::instance().unwearCollectibles(kind);
}

} // namespace Mirage
