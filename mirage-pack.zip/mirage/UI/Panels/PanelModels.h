#pragma once

#include "Core/Types.h"
#include <string>
#include <vector>
#include <functional>

namespace Mirage {

// UI-agnostic panel models. The real Qt/tdesktop boxes bind to these.
// This lets us finish behaviour fully even before the host UI is wired.

struct BalanceRow {
    std::string title;      // "Stars"
    std::string valueText;  // "50 000"
    Currency currency;
};

struct MenuRow {
    std::string id;
    std::string title;
    std::string subtitle;
    std::string icon;       // symbolic name
};

struct FragmentRow {
    std::string value;
    CollectibleKind kind;
    std::string priceText;
    Money price;
    bool owned = false;
};

struct CollectibleRow {
    CollectibleId id;
    std::string value;
    CollectibleKind kind;
    bool worn = false;
    std::string priceText;
};

// ---- Main settings panel model ----

class SettingsPanelModel {
public:
    std::vector<BalanceRow> balances() const;
    std::vector<MenuRow> sections() const;

    void refresh();
    void addStars(int64_t amount);
    void addRub(int64_t kopecks);
    void resetBalancesToDefault();

    bool realisticMode() const;
    void setRealisticMode(bool on);

    bool phantomRibbon() const;
    void setPhantomRibbon(bool on);
};

// ---- Fragment shop model ----

class FragmentShopModel {
public:
    void ensureCatalog();
    std::vector<FragmentRow> rows() const;
    bool buy(const FragmentRow &row); // false = not enough balance
    std::string lastError() const;

private:
    mutable std::string _lastError;
};

// ---- Profile customize model ----

class ProfileCustomizeModel {
public:
    ProfileOverlay overlay() const;
    void setUsername(const std::string &u, bool collectible);
    void clearUsername();
    void setPhone(const std::string &p, bool collectible);
    void clearPhone();
    void setFrameStyle(FrameStyle style);
    void setFrameColor(uint32_t argb);
    void setForcePremium(bool on);
    void reset();

    std::vector<CollectibleRow> ownedCollectibles() const;
    bool wear(CollectibleId id);
    void unwear(CollectibleKind kind);
};

// ---- Clone helper for menu ----

struct CloneMenuAction {
    static constexpr const char *kTitle = "Повторить профиль";
    static constexpr const char *kToast = "Профиль скопирован (только локально)";
};

} // namespace Mirage
