#include "MirageSettingsBox.h"
#include "UI/Panels/PanelModels.h"
#include "Fragment/FragmentService.h"
#include "Storage/LocalStore.h"

// This file describes the full behaviour of the settings / shop UI.
// When linked into tdesktop it is adapted to Ui::BoxContent + Ui::VerticalLayout.
// All business logic is already complete via PanelModels.

namespace Mirage {
namespace UiBoxes {

void ShowSettingsBox() {
    // Integration pseudo-code (real code uses Ui::show(Box<...>()) ):
    //
    // auto box = Box<SettingsBox>();
    // box->setTitle(tr("Mirage"));
    // auto *content = box->verticalLayout();
    //
    // SettingsPanelModel model;
    // model.refresh();
    //
    // // Balances card
    // for (const auto &b : model.balances()) {
    //     content->add(CreateBalanceRow(b.title, b.valueText));
    // }
    // content->add(CreateButton("Пополнить Stars", [&]{ model.addStars(10000); refresh(); }));
    // content->add(CreateButton("Сбросить балансы", [&]{ model.resetBalancesToDefault(); refresh(); }));
    //
    // // Sections
    // for (const auto &s : model.sections()) {
    //     content->add(CreateSectionButton(s.title, s.subtitle, [=]{
    //         if (s.id == "fragment") ShowFragmentShopBox();
    //         else if (s.id == "profile") ShowProfileCustomizeBox();
    //         ...
    //     }));
    // }
    //
    // // Toggles
    // content->add(CreateToggle("Реалистичный режим", model.realisticMode(),
    //     [&](bool v){ model.setRealisticMode(v); }));
    // content->add(CreateToggle("Лента «Фантом» на подарках", model.phantomRibbon(),
    //     [&](bool v){ model.setPhantomRibbon(v); }));
    //
    // Ui::show(std::move(box));
}

void ShowFragmentShopBox() {
    FragmentShopModel shop;
    shop.ensureCatalog();
    // Build list of FragmentRow, each with Buy button calling shop.buy(row)
    // On failure show toast with shop.lastError()
    // On success refresh list + balances
}

void ShowProfileCustomizeBox() {
    ProfileCustomizeModel model;
    // Fields:
    //  - username edit + "collectible" toggle + Apply / Clear
    //  - phone edit + collectible toggle + Apply / Clear
    //  - frame style picker (None/Simple/Gradient/Neon/Glass/Pulse)
    //  - color picker for frame
    //  - force premium toggle
    //  - list of owned collectibles with Wear / Unwear
    //  - Reset button
}

void ShowBalancesBox() {
    SettingsPanelModel model;
    // Detailed ledger view using LocalStore::ledger()
}

void FillSettingsContent(void * /*layout*/) {
    // Used when embedding into an existing AyuGram settings page
}

void FillFragmentShopContent(void * /*layout*/) {
}

} // namespace UiBoxes
} // namespace Mirage
