#pragma once

// tdesktop-style box. Requires Ui::BoxContent from Telegram Desktop.
// This header is written to match the patterns used in AyuGram/tdesktop boxes.

#include "Core/Types.h"
#include <QString>

// Forward declarations to avoid pulling entire tdesktop headers here.
namespace Ui { class BoxContent; class VerticalLayout; class SettingsButton; class FlatLabel; }

namespace Mirage {
namespace UiBoxes {

// Factory: create and show the main Mirage panel.
// Call from a hotkey or settings entry:
//   Ui::show(Box<Mirage::UiBoxes::SettingsBox>());
//
// Actual class inherits Ui::BoxContent in the .cpp when linked into tdesktop.

struct SettingsBoxArgs {
    // optional callbacks for host
};

// Public API used by integration code
void ShowSettingsBox();
void ShowFragmentShopBox();
void ShowProfileCustomizeBox();
void ShowBalancesBox();

// Helpers that build content into an existing VerticalLayout (for embedding)
void FillSettingsContent(/* Ui::VerticalLayout * */ void *layout);
void FillFragmentShopContent(/* Ui::VerticalLayout * */ void *layout);

} // namespace UiBoxes
} // namespace Mirage
