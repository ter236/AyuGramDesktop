#pragma once

#include <cstdint>
#include <string>
#include <vector>
#include <optional>
#include <chrono>

namespace Mirage {

// ---------------------------------------------------------------------------
// Common
// ---------------------------------------------------------------------------

using TimePoint = int64_t; // unix seconds
using PeerId = int64_t;
using GiftId = int64_t;
using CollectibleId = int64_t;

enum class Currency : uint8_t {
    Stars = 0,
    Ton = 1,
    Rub = 2,
};

struct Money {
    Currency currency = Currency::Stars;
    int64_t amount = 0; // smallest units (stars=1, ton nanos, rub kopecks)
};

// ---------------------------------------------------------------------------
// Profile Overlay (what YOU see on YOUR profile)
// ---------------------------------------------------------------------------

enum class FrameStyle : uint8_t {
    None = 0,
    Simple,
    Gradient,
    Neon,
    Glass,
    AnimatedPulse,
    AnimatedRotate,
    CustomImage,
};

struct ProfileFrame {
    FrameStyle style = FrameStyle::None;
    uint32_t primaryColor = 0xFF2AABEE;
    uint32_t secondaryColor = 0xFF6C5CE7;
    float thickness = 3.f;
    float cornerRadius = 0.f;
    std::string customImagePath; // relative to storage
    float animationSpeed = 1.f;
};

enum class BackgroundType : uint8_t {
    None = 0,
    Solid,
    Gradient,
    Image,
    BlurredAvatar,
};

struct ProfileBackground {
    BackgroundType type = BackgroundType::None;
    uint32_t primaryColor = 0xFF1C1C1E;
    uint32_t secondaryColor = 0xFF2C2C2E;
    std::string imagePath;
    float blurRadius = 20.f;
};

struct ProfileOverlay {
    // Visual identity
    std::optional<std::string> displayUsername;   // without @
    bool usernameCollectible = false;
    std::optional<std::string> displayPhone;      // +...
    bool phoneCollectible = false;

    ProfileFrame frame;
    ProfileBackground background;

    bool forcePremiumLook = false;
    std::optional<uint32_t> nameColor;
    std::optional<std::string> emojiStatusId;     // local visual only

    // Meta
    TimePoint updatedAt = 0;
};

// ---------------------------------------------------------------------------
// Collectibles (usernames / numbers)
// ---------------------------------------------------------------------------

enum class CollectibleKind : uint8_t {
    Username = 0,
    Phone = 1,
};

struct Collectible {
    CollectibleId id = 0;
    CollectibleKind kind = CollectibleKind::Username;
    std::string value;              // "duck" or "+8881234567"
    Money purchasePrice;
    TimePoint acquiredAt = 0;
    bool isWorn = false;            // currently shown on profile
    bool isListed = false;
    std::optional<Money> listPrice;
};

// ---------------------------------------------------------------------------
// Phantom Gifts
// ---------------------------------------------------------------------------

struct PhantomGift {
    GiftId id = 0;
    PeerId peerId = 0;              // who it is "for" / shown on
    std::string starGiftJson;       // serialized real StarGift-like data or slug
    std::string title;
    Money price;
    TimePoint date = 0;
    bool isReceived = false;        // "gift to me" flow
    bool pinnedToTop = false;
    bool savedToProfile = true;
    bool worn = false;
    std::optional<TimePoint> soldAt;
    std::optional<Money> marketPrice;
};

// ---------------------------------------------------------------------------
// Fragment (local marketplace)
// ---------------------------------------------------------------------------

struct FragmentListing {
    CollectibleId collectibleId = 0;
    CollectibleKind kind = CollectibleKind::Username;
    std::string value;
    Money price;
    TimePoint listedAt = 0;
    bool isOwnedByUser = false;
};

// ---------------------------------------------------------------------------
// Clone snapshot
// ---------------------------------------------------------------------------

struct ProfileCloneSnapshot {
    PeerId sourcePeerId = 0;
    std::string sourceName;
    std::string sourceUsername;
    ProfileOverlay overlay;         // what we copied into local overlay shape
    TimePoint clonedAt = 0;
};

// ---------------------------------------------------------------------------
// Ledger (for realism)
// ---------------------------------------------------------------------------

enum class LedgerKind : uint8_t {
    Purchase = 0,
    Sale,
    TransferIn,
    TransferOut,
    TopUp,
    Adjustment,
};

struct LedgerEntry {
    int64_t id = 0;
    Currency currency = Currency::Stars;
    LedgerKind kind = LedgerKind::Purchase;
    int64_t amount = 0;             // signed
    std::string title;
    std::string details;
    std::optional<PeerId> peerId;
    std::optional<GiftId> giftId;
    std::optional<CollectibleId> collectibleId;
    int64_t balanceAfter = 0;
    TimePoint createdAt = 0;
};

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

struct Settings {
    bool hiddenMenuEnabled = true;
    bool showPhantomRibbon = true;  // mark local gifts as "Phantom"
    bool realisticMode = true;      // hide most "this is fake" labels in UI

    int64_t fakeStarsBalance = 50000;
    int64_t fakeTonNanos = 0;
    int64_t fakeRubKopecks = 1000000; // 10 000 ₽

    ProfileOverlay profile;
};

} // namespace Mirage
