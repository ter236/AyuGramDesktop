#include "ProfileService.h"

namespace Mirage {

ProfileService &ProfileService::instance() {
    static ProfileService s;
    return s;
}

ProfileOverlay ProfileService::overlay() const {
    return LocalStore::instance().profileOverlay();
}

void ProfileService::setOverlay(const ProfileOverlay &o) {
    LocalStore::instance().setProfileOverlay(o);
}

void ProfileService::setDisplayUsername(const std::string &username, bool collectible) {
    auto o = overlay();
    o.displayUsername = username;
    o.usernameCollectible = collectible;
    setOverlay(o);
}

void ProfileService::setDisplayPhone(const std::string &phone, bool collectible) {
    auto o = overlay();
    o.displayPhone = phone;
    o.phoneCollectible = collectible;
    setOverlay(o);
}

void ProfileService::setFrame(const ProfileFrame &frame) {
    auto o = overlay();
    o.frame = frame;
    setOverlay(o);
}

void ProfileService::setBackground(const ProfileBackground &bg) {
    auto o = overlay();
    o.background = bg;
    setOverlay(o);
}

void ProfileService::setForcePremium(bool on) {
    auto o = overlay();
    o.forcePremiumLook = on;
    setOverlay(o);
}

void ProfileService::clearUsername() {
    auto o = overlay();
    o.displayUsername.reset();
    o.usernameCollectible = false;
    setOverlay(o);
}

void ProfileService::clearPhone() {
    auto o = overlay();
    o.displayPhone.reset();
    o.phoneCollectible = false;
    setOverlay(o);
}

void ProfileService::resetAll() {
    setOverlay(ProfileOverlay{});
}

bool ProfileService::wearCollectible(CollectibleId id) {
    auto list = LocalStore::instance().allCollectibles();
    Collectible *found = nullptr;
    for (auto &c : list) {
        if (c.id == id) { found = &c; break; }
    }
    if (!found) return false;

    // Unwear others of same kind
    LocalStore::instance().updateCollectible(id, [](Collectible &) {});
    for (const auto &c : LocalStore::instance().allCollectibles()) {
        if (c.kind == found->kind && c.id != id && c.isWorn) {
            LocalStore::instance().updateCollectible(c.id, [](Collectible &x) { x.isWorn = false; });
        }
    }
    LocalStore::instance().updateCollectible(id, [](Collectible &x) { x.isWorn = true; });

    if (found->kind == CollectibleKind::Username) {
        setDisplayUsername(found->value, true);
    } else {
        setDisplayPhone(found->value, true);
    }
    LocalStore::instance().save();
    return true;
}

void ProfileService::unwearCollectibles(CollectibleKind kind) {
    for (const auto &c : LocalStore::instance().allCollectibles()) {
        if (c.kind == kind && c.isWorn) {
            LocalStore::instance().updateCollectible(c.id, [](Collectible &x) { x.isWorn = false; });
        }
    }
    if (kind == CollectibleKind::Username) clearUsername();
    else clearPhone();
    LocalStore::instance().save();
}

std::optional<std::string> ProfileService::effectiveUsername() const {
    return overlay().displayUsername;
}

std::optional<std::string> ProfileService::effectivePhone() const {
    return overlay().displayPhone;
}

bool ProfileService::effectivePremiumLook() const {
    return overlay().forcePremiumLook;
}

ProfileFrame ProfileService::effectiveFrame() const {
    return overlay().frame;
}

} // namespace Mirage
