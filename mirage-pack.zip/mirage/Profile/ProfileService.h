#pragma once

#include "Core/Types.h"
#include "Storage/LocalStore.h"

namespace Mirage {

// Applies and manages the local visual profile overlay.
// Call sites in tdesktop:
//  - Info::Profile::Cover / Userpic
//  - PeerData::userName / phone display paths
//  - Name color / premium badge painting

class ProfileService {
public:
    static ProfileService &instance();

    // Current overlay (what to show instead of real data for self)
    ProfileOverlay overlay() const;
    void setOverlay(const ProfileOverlay &o);

    // Convenience
    void setDisplayUsername(const std::string &username, bool collectible);
    void setDisplayPhone(const std::string &phone, bool collectible);
    void setFrame(const ProfileFrame &frame);
    void setBackground(const ProfileBackground &bg);
    void setForcePremium(bool on);
    void clearUsername();
    void clearPhone();
    void resetAll();

    // Wear a collectible username/phone onto the profile
    bool wearCollectible(CollectibleId id);
    void unwearCollectibles(CollectibleKind kind);

    // For UI: effective values to paint
    std::optional<std::string> effectiveUsername() const;
    std::optional<std::string> effectivePhone() const;
    bool effectivePremiumLook() const;
    ProfileFrame effectiveFrame() const;
};

} // namespace Mirage
