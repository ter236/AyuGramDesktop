#include "GiftService.h"
#include "Storage/LocalStore.h"
#include <ctime>

namespace Mirage {

GiftService &GiftService::instance() {
    static GiftService s;
    return s;
}

GiftId GiftService::sendPhantom(
    PeerId peerId,
    const std::string &title,
    Money price,
    bool asReceived) {

    auto &store = LocalStore::instance();

    if (!asReceived) {
        if (!store.trySpend(price.currency, price.amount, "Подарок", title)) {
            return 0;
        }
    }

    PhantomGift g;
    g.id = store.nextGiftId();
    g.peerId = peerId;
    g.title = title;
    g.price = price;
    g.date = static_cast<TimePoint>(std::time(nullptr));
    g.isReceived = asReceived;
    g.savedToProfile = true;
    store.addGift(g);
    store.save();
    return g.id;
}

std::vector<PhantomGift> GiftService::forPeer(PeerId peerId) const {
    return LocalStore::instance().giftsForPeer(peerId);
}

std::vector<PhantomGift> GiftService::all() const {
    return LocalStore::instance().allGifts();
}

void GiftService::setWorn(GiftId id, bool worn) {
    LocalStore::instance().updateGift(id, [worn](PhantomGift &g) { g.worn = worn; });
    LocalStore::instance().save();
}

void GiftService::setPinned(GiftId id, bool pinned) {
    LocalStore::instance().updateGift(id, [pinned](PhantomGift &g) { g.pinnedToTop = pinned; });
    LocalStore::instance().save();
}

void GiftService::setSavedToProfile(GiftId id, bool saved) {
    LocalStore::instance().updateGift(id, [saved](PhantomGift &g) { g.savedToProfile = saved; });
    LocalStore::instance().save();
}

void GiftService::remove(GiftId id) {
    LocalStore::instance().removeGift(id);
    LocalStore::instance().save();
}

bool GiftService::sell(GiftId id, Money price) {
    bool found = false;
    LocalStore::instance().updateGift(id, [&](PhantomGift &g) {
        found = true;
        g.soldAt = static_cast<TimePoint>(std::time(nullptr));
        g.savedToProfile = false;
        g.worn = false;
    });
    if (!found) return false;
    LocalStore::instance().credit(price.currency, price.amount, "Продажа подарка", "");
    LocalStore::instance().save();
    return true;
}

} // namespace Mirage
