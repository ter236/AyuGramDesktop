#pragma once

#include "Core/Types.h"
#include <vector>
#include <string>

namespace Mirage {

class GiftService {
public:
    static GiftService &instance();

    // Create a local phantom gift for peer (or self)
    GiftId sendPhantom(
        PeerId peerId,
        const std::string &title,
        Money price,
        bool asReceived);

    std::vector<PhantomGift> forPeer(PeerId peerId) const;
    std::vector<PhantomGift> all() const;

    void setWorn(GiftId id, bool worn);
    void setPinned(GiftId id, bool pinned);
    void setSavedToProfile(GiftId id, bool saved);
    void remove(GiftId id);

    // Sell locally (credit balance, mark sold)
    bool sell(GiftId id, Money price);
};

} // namespace Mirage
