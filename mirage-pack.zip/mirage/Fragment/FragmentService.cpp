#include "FragmentService.h"
#include "Storage/LocalStore.h"
#include "Profile/ProfileService.h"
#include <random>
#include <ctime>

namespace Mirage {

FragmentService &FragmentService::instance() {
    static FragmentService s;
    return s;
}

void FragmentService::ensureDemoCatalog() {
    auto &store = LocalStore::instance();
    if (!store.fragmentListings().empty()) return;

    const char *names[] = {
        "alpha", "nova", "pulse", "vertex", "quark", "nebula",
        "cipher", "flux", "monolith", "echo", "prism", "orbit",
        "duck", "grok", "pixel", "shadow", "blaze", "frost"
    };
    std::vector<FragmentListing> list;
    int64_t id = 1;
    for (const char *n : names) {
        FragmentListing l;
        l.collectibleId = id++;
        l.kind = CollectibleKind::Username;
        l.value = n;
        l.price = { Currency::Stars, 5000 + (id * 137) % 45000 };
        l.listedAt = static_cast<TimePoint>(std::time(nullptr));
        l.isOwnedByUser = false;
        list.push_back(l);
    }
    // A few phone-style
    for (int i = 0; i < 6; ++i) {
        FragmentListing l;
        l.collectibleId = id++;
        l.kind = CollectibleKind::Phone;
        l.value = "+888" + std::to_string(1000000 + i * 17353);
        l.price = { Currency::Stars, 15000 + i * 3000 };
        l.listedAt = static_cast<TimePoint>(std::time(nullptr));
        l.isOwnedByUser = false;
        list.push_back(l);
    }
    store.setFragmentListings(std::move(list));
    store.save();
}

std::vector<FragmentListing> FragmentService::catalog() const {
    return LocalStore::instance().fragmentListings();
}

bool FragmentService::buy(const std::string &value, CollectibleKind kind, Money price) {
    auto &store = LocalStore::instance();
    if (!store.trySpend(price.currency, price.amount,
                        kind == CollectibleKind::Username ? "Fragment: username" : "Fragment: number",
                        value)) {
        return false;
    }

    Collectible c;
    c.id = store.nextCollectibleId();
    c.kind = kind;
    c.value = value;
    c.purchasePrice = price;
    c.acquiredAt = static_cast<TimePoint>(std::time(nullptr));
    c.isWorn = false;
    store.addCollectible(c);

    // Remove from catalog or mark owned
    auto list = store.fragmentListings();
    for (auto &l : list) {
        if (l.value == value && l.kind == kind) {
            l.isOwnedByUser = true;
        }
    }
    store.setFragmentListings(list);
    store.save();
    return true;
}

bool FragmentService::listForSale(CollectibleId id, Money price) {
    bool ok = false;
    LocalStore::instance().updateCollectible(id, [&](Collectible &c) {
        c.isListed = true;
        c.listPrice = price;
        ok = true;
    });
    if (ok) LocalStore::instance().save();
    return ok;
}

bool FragmentService::unlist(CollectibleId id) {
    bool ok = false;
    LocalStore::instance().updateCollectible(id, [&](Collectible &c) {
        c.isListed = false;
        c.listPrice.reset();
        ok = true;
    });
    if (ok) LocalStore::instance().save();
    return ok;
}

std::vector<std::string> FragmentService::suggestUsernames(int count) const {
    static const char *pool[] = {
        "aurora", "zenith", "cobalt", "ember", "glyph", "helix",
        "ion", "jade", "krypton", "lunar", "myth", "nimbus"
    };
    std::vector<std::string> out;
    for (int i = 0; i < count && i < 12; ++i) {
        out.push_back(pool[i]);
    }
    return out;
}

std::vector<std::string> FragmentService::suggestPhones(int count) const {
    std::vector<std::string> out;
    for (int i = 0; i < count; ++i) {
        out.push_back("+888" + std::to_string(2000000 + i * 9013));
    }
    return out;
}

} // namespace Mirage
