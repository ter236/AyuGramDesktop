#pragma once

#include "Core/Types.h"
#include <vector>
#include <string>

namespace Mirage {

// Local Fragment-like marketplace for collectible usernames and numbers.
// No network. Catalog is generated + user-owned items.

class FragmentService {
public:
    static FragmentService &instance();

    // Seed a demo catalog if empty (realistic-looking names/numbers)
    void ensureDemoCatalog();

    std::vector<FragmentListing> catalog() const;

    // Buy from catalog → creates Collectible + ledger entry, spends local balance
    bool buy(const std::string &value, CollectibleKind kind, Money price);

    // List owned collectible for "sale" (local only)
    bool listForSale(CollectibleId id, Money price);
    bool unlist(CollectibleId id);

    // Generate a few random-looking available usernames for the shop UI
    std::vector<std::string> suggestUsernames(int count = 12) const;
    std::vector<std::string> suggestPhones(int count = 8) const;
};

} // namespace Mirage
