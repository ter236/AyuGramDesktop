// Mirage — integration hooks (kept free of tdesktop-specific APIs)
#include "mirage/mirage_hooks.h"

#include "mirage/Storage/LocalStore.h"
#include "mirage/Fragment/FragmentService.h"
#include "mirage/Clone/CloneService.h"

#include <QtCore/QStandardPaths>
#include <QtCore/QDir>

namespace Mirage {

void EnsureInit() {
	static bool done = false;
	if (done) {
		return;
	}
	done = true;
	const auto dir = QStandardPaths::writableLocation(
		QStandardPaths::AppDataLocation) + "/Mirage";
	QDir().mkpath(dir);
	LocalStore::instance().setRootPath(dir.toStdString());
	LocalStore::instance().load();
	FragmentService::instance().ensureDemoCatalog();
}

QString CloneMenuText() {
	return QString::fromUtf8("Повторить профиль");
}

void CloneProfile(
		long long peerId,
		const QString &displayName,
		const QString &username,
		bool hasPremium) {
	EnsureInit();
	CloneSource src;
	src.peerId = peerId;
	src.displayName = displayName.toStdString();
	src.username = username.toStdString();
	src.hasPremium = hasPremium;
	CloneService::instance().applyClone(src);
}

} // namespace Mirage
