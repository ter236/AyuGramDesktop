#pragma once

#include "Core/Types.h"
#include <string>

namespace Mirage {

// "Повторить профиль" — copies visual traits from another peer into local overlay.
// Only uses data already available on the client (name, username, photo reference, etc.).
// Never requests or modifies anything on the server.

struct CloneSource {
    PeerId peerId = 0;
    std::string displayName;
    std::string username;       // without @
    bool hasPremium = false;
    // Future: photo path / emoji status / visible gifts count etc.
};

class CloneService {
public:
    static CloneService &instance();

    // Build overlay from source and apply to local profile
    bool applyClone(const CloneSource &source);

    // History of clones
    std::vector<ProfileCloneSnapshot> history() const;
};

} // namespace Mirage
