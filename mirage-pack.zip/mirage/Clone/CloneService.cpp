#include "CloneService.h"
#include "Storage/LocalStore.h"
#include "Profile/ProfileService.h"
#include <ctime>

namespace Mirage {

CloneService &CloneService::instance() {
    static CloneService s;
    return s;
}

bool CloneService::applyClone(const CloneSource &source) {
    ProfileOverlay o = ProfileService::instance().overlay();

    if (!source.username.empty()) {
        o.displayUsername = source.username;
        o.usernameCollectible = false; // real username style unless we know otherwise
    }
    o.forcePremiumLook = source.hasPremium;

    // Keep existing frame/background unless we later pull more visual data
    o.updatedAt = static_cast<TimePoint>(std::time(nullptr));
    ProfileService::instance().setOverlay(o);

    ProfileCloneSnapshot snap;
    snap.sourcePeerId = source.peerId;
    snap.sourceName = source.displayName;
    snap.sourceUsername = source.username;
    snap.overlay = o;
    snap.clonedAt = o.updatedAt;
    LocalStore::instance().addCloneSnapshot(snap);
    LocalStore::instance().save();
    return true;
}

std::vector<ProfileCloneSnapshot> CloneService::history() const {
    return LocalStore::instance().cloneHistory();
}

} // namespace Mirage
