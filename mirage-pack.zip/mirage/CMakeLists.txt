# Mirage module — add to parent Telegram CMake
set(MIRAGE_SOURCES
    mirage_hooks.cpp
    Storage/LocalStore.cpp
    Profile/ProfileService.cpp
    Fragment/FragmentService.cpp
    Gifts/GiftService.cpp
    Clone/CloneService.cpp
    UI/Paint/FramePainter.cpp
    UI/Panels/PanelModels.cpp
    UI/Boxes/MirageSettingsBox.cpp
)

add_library(mirage OBJECT ${MIRAGE_SOURCES})
target_include_directories(mirage PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/..)
# Parent target should: target_link_libraries(Telegram PRIVATE mirage)
# and ensure Qt + tdesktop headers are visible (same as other SourceFiles).
