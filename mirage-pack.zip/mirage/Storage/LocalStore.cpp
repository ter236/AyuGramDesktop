#include "LocalStore.h"

#include <fstream>
#include <sstream>
#include <algorithm>

// Minimal persistence without external JSON lib for the first drop.
// Format: simple line-based key sections. Easy to inspect and debug.
// Later can be swapped to nlohmann::json (tdesktop already vendors it in some forks).

namespace Mirage {
namespace {

std::string escape(const std::string &s) {
    std::string out;
    out.reserve(s.size());
    for (char c : s) {
        if (c == '\n' || c == '\r' || c == '|') out.push_back('_');
        else out.push_back(c);
    }
    return out;
}

} // namespace

LocalStore &LocalStore::instance() {
    static LocalStore s;
    return s;
}

void LocalStore::setRootPath(const std::filesystem::path &path) {
    std::lock_guard lock(_mutex);
    _root = path;
}

std::filesystem::path LocalStore::rootPath() const {
    std::lock_guard lock(_mutex);
    return _root;
}

std::filesystem::path LocalStore::storeFile() const {
    return _root / "Mirage" / "store.v1.txt";
}

bool LocalStore::load() {
    std::lock_guard lock(_mutex);
    const auto path = storeFile();
    if (!std::filesystem::exists(path)) {
        // defaults already in _settings
        return true;
    }
    std::ifstream in(path);
    if (!in) return false;

    // Very small parser for prototype. Sections: [settings] [collectible] [gift] ...
    std::string line;
    std::string section;
    Collectible curCol;
    PhantomGift curGift;
    bool hasCol = false, hasGift = false;

    auto flushCol = [&]() {
        if (hasCol) {
            _collectibles.push_back(curCol);
            _nextCollectibleId = std::max(_nextCollectibleId, curCol.id + 1);
            curCol = {};
            hasCol = false;
        }
    };
    auto flushGift = [&]() {
        if (hasGift) {
            _gifts.push_back(curGift);
            _nextGiftId = std::max(_nextGiftId, curGift.id + 1);
            curGift = {};
            hasGift = false;
        }
    };

    while (std::getline(in, line)) {
        if (line.empty() || line[0] == '#') continue;
        if (line[0] == '[') {
            flushCol();
            flushGift();
            section = line;
            continue;
        }
        const auto eq = line.find('=');
        if (eq == std::string::npos) continue;
        const auto key = line.substr(0, eq);
        const auto val = line.substr(eq + 1);

        if (section == "[settings]") {
            if (key == "stars") _settings.fakeStarsBalance = std::stoll(val);
            else if (key == "ton") _settings.fakeTonNanos = std::stoll(val);
            else if (key == "rub") _settings.fakeRubKopecks = std::stoll(val);
            else if (key == "realistic") _settings.realisticMode = (val == "1");
            else if (key == "phantom_ribbon") _settings.showPhantomRibbon = (val == "1");
            else if (key == "username") _settings.profile.displayUsername = val;
            else if (key == "username_col") _settings.profile.usernameCollectible = (val == "1");
            else if (key == "phone") _settings.profile.displayPhone = val;
            else if (key == "phone_col") _settings.profile.phoneCollectible = (val == "1");
            else if (key == "frame_style") _settings.profile.frame.style = static_cast<FrameStyle>(std::stoi(val));
            else if (key == "frame_color") _settings.profile.frame.primaryColor = static_cast<uint32_t>(std::stoul(val));
            else if (key == "force_premium") _settings.profile.forcePremiumLook = (val == "1");
        } else if (section == "[collectible]") {
            hasCol = true;
            if (key == "id") curCol.id = std::stoll(val);
            else if (key == "kind") curCol.kind = static_cast<CollectibleKind>(std::stoi(val));
            else if (key == "value") curCol.value = val;
            else if (key == "worn") curCol.isWorn = (val == "1");
            else if (key == "price") curCol.purchasePrice.amount = std::stoll(val);
            else if (key == "currency") curCol.purchasePrice.currency = static_cast<Currency>(std::stoi(val));
        } else if (section == "[gift]") {
            hasGift = true;
            if (key == "id") curGift.id = std::stoll(val);
            else if (key == "peer") curGift.peerId = std::stoll(val);
            else if (key == "title") curGift.title = val;
            else if (key == "price") curGift.price.amount = std::stoll(val);
            else if (key == "currency") curGift.price.currency = static_cast<Currency>(std::stoi(val));
            else if (key == "date") curGift.date = std::stoll(val);
            else if (key == "received") curGift.isReceived = (val == "1");
            else if (key == "saved") curGift.savedToProfile = (val == "1");
            else if (key == "worn") curGift.worn = (val == "1");
            else if (key == "pinned") curGift.pinnedToTop = (val == "1");
        }
    }
    flushCol();
    flushGift();
    return true;
}

bool LocalStore::save() {
    std::lock_guard lock(_mutex);
    const auto dir = _root / "Mirage";
    std::error_code ec;
    std::filesystem::create_directories(dir, ec);
    std::ofstream out(storeFile(), std::ios::trunc);
    if (!out) return false;

    out << "# Mirage local store v1 — do not edit while app is running\n";
    out << "[settings]\n";
    out << "stars=" << _settings.fakeStarsBalance << "\n";
    out << "ton=" << _settings.fakeTonNanos << "\n";
    out << "rub=" << _settings.fakeRubKopecks << "\n";
    out << "realistic=" << (_settings.realisticMode ? 1 : 0) << "\n";
    out << "phantom_ribbon=" << (_settings.showPhantomRibbon ? 1 : 0) << "\n";
    if (_settings.profile.displayUsername)
        out << "username=" << escape(*_settings.profile.displayUsername) << "\n";
    out << "username_col=" << (_settings.profile.usernameCollectible ? 1 : 0) << "\n";
    if (_settings.profile.displayPhone)
        out << "phone=" << escape(*_settings.profile.displayPhone) << "\n";
    out << "phone_col=" << (_settings.profile.phoneCollectible ? 1 : 0) << "\n";
    out << "frame_style=" << static_cast<int>(_settings.profile.frame.style) << "\n";
    out << "frame_color=" << _settings.profile.frame.primaryColor << "\n";
    out << "force_premium=" << (_settings.profile.forcePremiumLook ? 1 : 0) << "\n";
    out << "\n";

    for (const auto &c : _collectibles) {
        out << "[collectible]\n";
        out << "id=" << c.id << "\n";
        out << "kind=" << static_cast<int>(c.kind) << "\n";
        out << "value=" << escape(c.value) << "\n";
        out << "worn=" << (c.isWorn ? 1 : 0) << "\n";
        out << "price=" << c.purchasePrice.amount << "\n";
        out << "currency=" << static_cast<int>(c.purchasePrice.currency) << "\n";
        out << "\n";
    }

    for (const auto &g : _gifts) {
        out << "[gift]\n";
        out << "id=" << g.id << "\n";
        out << "peer=" << g.peerId << "\n";
        out << "title=" << escape(g.title) << "\n";
        out << "price=" << g.price.amount << "\n";
        out << "currency=" << static_cast<int>(g.price.currency) << "\n";
        out << "date=" << g.date << "\n";
        out << "received=" << (g.isReceived ? 1 : 0) << "\n";
        out << "saved=" << (g.savedToProfile ? 1 : 0) << "\n";
        out << "worn=" << (g.worn ? 1 : 0) << "\n";
        out << "pinned=" << (g.pinnedToTop ? 1 : 0) << "\n";
        out << "\n";
    }

    return true;
}

// ---- settings ----

Settings LocalStore::settings() const {
    std::lock_guard lock(_mutex);
    return _settings;
}

void LocalStore::updateSettings(std::function<void(Settings &)> mutator) {
    std::lock_guard lock(_mutex);
    mutator(_settings);
    // save outside lock would be better; for prototype we save eagerly
}

ProfileOverlay LocalStore::profileOverlay() const {
    return settings().profile;
}

void LocalStore::setProfileOverlay(const ProfileOverlay &overlay) {
    updateSettings([&](Settings &s) {
        s.profile = overlay;
        s.profile.updatedAt = static_cast<TimePoint>(std::time(nullptr));
    });
    save();
}

// ---- collectibles ----

std::vector<Collectible> LocalStore::allCollectibles() const {
    std::lock_guard lock(_mutex);
    return _collectibles;
}

std::vector<Collectible> LocalStore::ownedCollectibles() const {
    return allCollectibles();
}

void LocalStore::addCollectible(const Collectible &c) {
    std::lock_guard lock(_mutex);
    _collectibles.push_back(c);
}

void LocalStore::updateCollectible(CollectibleId id, std::function<void(Collectible &)> mutator) {
    std::lock_guard lock(_mutex);
    for (auto &c : _collectibles) {
        if (c.id == id) {
            mutator(c);
            break;
        }
    }
}

void LocalStore::removeCollectible(CollectibleId id) {
    std::lock_guard lock(_mutex);
    _collectibles.erase(std::remove_if(_collectibles.begin(), _collectibles.end(),
        [id](const Collectible &c) { return c.id == id; }), _collectibles.end());
}

CollectibleId LocalStore::nextCollectibleId() {
    std::lock_guard lock(_mutex);
    return _nextCollectibleId++;
}

// ---- gifts ----

std::vector<PhantomGift> LocalStore::allGifts() const {
    std::lock_guard lock(_mutex);
    return _gifts;
}

std::vector<PhantomGift> LocalStore::giftsForPeer(PeerId peerId) const {
    std::lock_guard lock(_mutex);
    std::vector<PhantomGift> out;
    for (const auto &g : _gifts) {
        if (g.peerId == peerId) out.push_back(g);
    }
    return out;
}

void LocalStore::addGift(const PhantomGift &g) {
    std::lock_guard lock(_mutex);
    _gifts.push_back(g);
}

void LocalStore::updateGift(GiftId id, std::function<void(PhantomGift &)> mutator) {
    std::lock_guard lock(_mutex);
    for (auto &g : _gifts) {
        if (g.id == id) {
            mutator(g);
            break;
        }
    }
}

void LocalStore::removeGift(GiftId id) {
    std::lock_guard lock(_mutex);
    _gifts.erase(std::remove_if(_gifts.begin(), _gifts.end(),
        [id](const PhantomGift &g) { return g.id == id; }), _gifts.end());
}

GiftId LocalStore::nextGiftId() {
    std::lock_guard lock(_mutex);
    return _nextGiftId++;
}

// ---- fragment / clones / ledger (stubs with storage) ----

std::vector<FragmentListing> LocalStore::fragmentListings() const {
    std::lock_guard lock(_mutex);
    return _fragment;
}

void LocalStore::setFragmentListings(std::vector<FragmentListing> list) {
    std::lock_guard lock(_mutex);
    _fragment = std::move(list);
}

void LocalStore::addFragmentListing(const FragmentListing &l) {
    std::lock_guard lock(_mutex);
    _fragment.push_back(l);
}

std::vector<ProfileCloneSnapshot> LocalStore::cloneHistory() const {
    std::lock_guard lock(_mutex);
    return _clones;
}

void LocalStore::addCloneSnapshot(const ProfileCloneSnapshot &s) {
    std::lock_guard lock(_mutex);
    _clones.push_back(s);
}

std::vector<LedgerEntry> LocalStore::ledger(Currency currency) const {
    std::lock_guard lock(_mutex);
    std::vector<LedgerEntry> out;
    for (const auto &e : _ledger) {
        if (e.currency == currency) out.push_back(e);
    }
    return out;
}

void LocalStore::addLedger(const LedgerEntry &e) {
    std::lock_guard lock(_mutex);
    _ledger.push_back(e);
}

int64_t LocalStore::nextLedgerId() {
    std::lock_guard lock(_mutex);
    return _nextLedgerId++;
}

// ---- balances ----

int64_t LocalStore::starsBalance() const { return settings().fakeStarsBalance; }
int64_t LocalStore::tonNanos() const { return settings().fakeTonNanos; }
int64_t LocalStore::rubKopecks() const { return settings().fakeRubKopecks; }

bool LocalStore::trySpend(Currency c, int64_t amount, const std::string &title, const std::string &details) {
    std::lock_guard lock(_mutex);
    int64_t *bal = nullptr;
    switch (c) {
    case Currency::Stars: bal = &_settings.fakeStarsBalance; break;
    case Currency::Ton:   bal = &_settings.fakeTonNanos; break;
    case Currency::Rub:   bal = &_settings.fakeRubKopecks; break;
    }
    if (!bal || *bal < amount) return false;
    *bal -= amount;
    LedgerEntry e;
    e.id = _nextLedgerId++;
    e.currency = c;
    e.kind = LedgerKind::Purchase;
    e.amount = -amount;
    e.title = title;
    e.details = details;
    e.balanceAfter = *bal;
    e.createdAt = static_cast<TimePoint>(std::time(nullptr));
    _ledger.push_back(e);
    return true;
}

void LocalStore::credit(Currency c, int64_t amount, const std::string &title, const std::string &details) {
    std::lock_guard lock(_mutex);
    int64_t *bal = nullptr;
    switch (c) {
    case Currency::Stars: bal = &_settings.fakeStarsBalance; break;
    case Currency::Ton:   bal = &_settings.fakeTonNanos; break;
    case Currency::Rub:   bal = &_settings.fakeRubKopecks; break;
    }
    if (!bal) return;
    *bal += amount;
    LedgerEntry e;
    e.id = _nextLedgerId++;
    e.currency = c;
    e.kind = LedgerKind::TopUp;
    e.amount = amount;
    e.title = title;
    e.details = details;
    e.balanceAfter = *bal;
    e.createdAt = static_cast<TimePoint>(std::time(nullptr));
    _ledger.push_back(e);
}

} // namespace Mirage
