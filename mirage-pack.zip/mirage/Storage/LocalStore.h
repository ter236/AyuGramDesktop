#pragma once

#include "Core/Types.h"
#include <filesystem>
#include <mutex>
#include <functional>

namespace Mirage {

// Simple JSON-backed local store.
// Path: <tdata or appdata>/Mirage/store.json
// Thread-safe for basic use.

class LocalStore {
public:
    static LocalStore &instance();

    void setRootPath(const std::filesystem::path &path);
    std::filesystem::path rootPath() const;

    bool load();
    bool save();

    // Settings + balances
    Settings settings() const;
    void updateSettings(std::function<void(Settings &)> mutator);

    // Profile overlay shortcuts
    ProfileOverlay profileOverlay() const;
    void setProfileOverlay(const ProfileOverlay &overlay);

    // Collectibles
    std::vector<Collectible> allCollectibles() const;
    std::vector<Collectible> ownedCollectibles() const;
    void addCollectible(const Collectible &c);
    void updateCollectible(CollectibleId id, std::function<void(Collectible &)> mutator);
    void removeCollectible(CollectibleId id);
    CollectibleId nextCollectibleId();

    // Phantom gifts
    std::vector<PhantomGift> allGifts() const;
    std::vector<PhantomGift> giftsForPeer(PeerId peerId) const;
    void addGift(const PhantomGift &g);
    void updateGift(GiftId id, std::function<void(PhantomGift &)> mutator);
    void removeGift(GiftId id);
    GiftId nextGiftId();

    // Fragment listings (catalog + owned)
    std::vector<FragmentListing> fragmentListings() const;
    void setFragmentListings(std::vector<FragmentListing> list);
    void addFragmentListing(const FragmentListing &l);

    // Clone history
    std::vector<ProfileCloneSnapshot> cloneHistory() const;
    void addCloneSnapshot(const ProfileCloneSnapshot &s);

    // Ledger
    std::vector<LedgerEntry> ledger(Currency currency = Currency::Stars) const;
    void addLedger(const LedgerEntry &e);
    int64_t nextLedgerId();

    // Balances helpers
    int64_t starsBalance() const;
    int64_t tonNanos() const;
    int64_t rubKopecks() const;
    bool trySpend(Currency c, int64_t amount, const std::string &title, const std::string &details);
    void credit(Currency c, int64_t amount, const std::string &title, const std::string &details);

private:
    LocalStore() = default;

    mutable std::mutex _mutex;
    std::filesystem::path _root;
    Settings _settings;
    std::vector<Collectible> _collectibles;
    std::vector<PhantomGift> _gifts;
    std::vector<FragmentListing> _fragment;
    std::vector<ProfileCloneSnapshot> _clones;
    std::vector<LedgerEntry> _ledger;

    CollectibleId _nextCollectibleId = 1;
    GiftId _nextGiftId = 1;
    int64_t _nextLedgerId = 1;

    std::filesystem::path storeFile() const;
};

} // namespace Mirage
